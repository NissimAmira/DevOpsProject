# DevOps Project

A simple Flask web application containerized with Docker.

## Project Structure

```
DevOpsProject/
├── Dockerfile
├── docker-compose.yml
├── README.md
└── app/
    ├── app.py
    └── requirements.txt
```

## Prerequisites

- Docker
- Docker Compose (optional, for easier management)

## Building and Running the Docker Container

### Method 1: Using Docker Commands

1. **Build the Docker image:**
   ```bash
   docker build -t flask-app .
   ```

2. **Run the container:**
   ```bash
   docker run -p 5000:5000 flask-app
   ```

3. **Access the application:**
   Open your browser and go to `http://localhost:5000`

### Method 2: Using Docker Compose

1. **Build and run with Docker Compose:**
   ```bash
   docker-compose up --build
   ```

2. **Run in detached mode (background):**
   ```bash
   docker-compose up -d --build
   ```

3. **Stop the application:**
   ```bash
   docker-compose down
   ```

4. **Access the application:**
   Open your browser and go to `http://localhost:5000`

## Development

The application is a simple Flask web server that serves a "Hello World!" message on the root endpoint (`/`).

### Application Details

- **Framework:** Flask
- **Port:** 5000
- **Endpoint:** `/` returns "Hello World!"

### Docker Configuration

- **Base Image:** python:3.12-slim
- **Working Directory:** /app
- **Exposed Port:** 5000
- **Dependencies:** Flask (from requirements.txt)

## Troubleshooting

- Ensure Docker is running before executing any Docker commands
- Use `docker logs <container-id>` to view container logs if the application doesn't start properly